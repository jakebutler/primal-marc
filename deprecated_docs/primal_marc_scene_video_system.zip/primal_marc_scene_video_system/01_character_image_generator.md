
# Character Image Generator Prompt

Generate a single reusable reference image for a character.
Supports humans, animals, plants, objects, and imaginary entities.
Character must be visually stable and capable of action or expression.

Output JSON:
{
  "prompt": "<image generation prompt>"
}

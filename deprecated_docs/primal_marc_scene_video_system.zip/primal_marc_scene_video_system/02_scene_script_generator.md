
# Scene Script Generator Prompt

Break a concept into 4–6 scenes (~5–6s each).
One persistent character.
Each scene has start frame, end frame, and motion.

Output JSON:
{
  "character": {...},
  "scenes": [...]
}


# Example — Anthropomorphic Cactus

Character:
A saguaro cactus with arms and subtle facial features.

Scenes:
1. Curious cactus at sunrise
2. Learning by arranging stones
3. Pattern collapse and retry
4. Confident understanding at full light

Designed to demonstrate non‑human character persistence.

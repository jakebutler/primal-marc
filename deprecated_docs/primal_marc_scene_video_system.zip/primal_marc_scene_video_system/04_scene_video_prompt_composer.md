
# Scene Video Prompt Composer

Describe motion between start and end frames.
Defaults:
- Duration ~5–6s
- Camera: medium framing, slow track right

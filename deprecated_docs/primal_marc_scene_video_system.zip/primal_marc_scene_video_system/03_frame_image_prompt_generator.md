
# Frame Image Prompt Generator

Generate start and end frame prompts for one scene.
Always include reference character.
No motion in frames.

Output JSON:
{
  "start_frame_prompt": "...",
  "end_frame_prompt": "..."
}

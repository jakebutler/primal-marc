# MiniMax Blog – Prototype Walkthrough (VERBATIM)

## Initial User Input
Started by doing research on what makes a good video generation prompt since I haven't done that before.

*link to Hailuo guidance*
*insert link to other research I assembled*

I started generating some videos but I quickly realized that a) the 30sec duration was just a demo and the API was limited to 10sec, often only generating 6sec

This was okay, but not impressive at all. I also found that all my videos were coming up very abstract, overwhelmingly looked AI-generated, and just were meh.

I took a look at some of the interesting videos on the Hailuo web app, and saw the pattern that all of the prompts had a simple description of the scenario, but asked that you pass in an image of yourself as reference. Conclusion 1: require a clear subject in the video. Conclusion 2: describe the scene and acction of the scene.

Updating the video gen prompt with that guidance got me so much further - requiring a character and describing a scene + action. It seems pretty basic, but so often you (I) end up learning these lessons by doing. I over-engineered and over-thought the approach initially.

Next step - I'm trying to showcase the multi-modality of Minimax's APIs; what else can I do?

Ultimately, I came up with this workflow to make longer videos:
*Paste multi-step workflow here*

Shoutouts to Petros Hong for hosting and all the good vibes, Bolt and MiniMax for sponsoring, and MiniMax especially for helping out with questions during the hackathon!

## User Selections (Verbatim)
- Content recency: Recent
- Blog type option selected: C
- Citation style: Full quotes

## Missing Verbatim Outputs
The following outputs were generated earlier but are **not present verbatim in this conversation log** and therefore are intentionally NOT reconstructed:
- Agent 1 clarification questions and outputs
- Agent 2 research excerpts
- Agent 3 full blog draft
- Agent 4 edited draft
- Agent 5 metadata and social posts


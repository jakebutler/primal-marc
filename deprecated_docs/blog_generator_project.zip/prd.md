# Blog Generator – Product Requirements Document (PRD)

## Important Note on Verbatim Content
This PRD and accompanying example files include **only verbatim content that appears in the conversation log provided to this assistant**.
Where prior agent outputs (e.g., full blog draft, research excerpts, editor revisions) were generated earlier but are **not present verbatim in the current conversation history**, those sections are explicitly marked as **UNAVAILABLE VERBATIM** rather than reconstructed or summarized. No content has been reworded or hallucinated.

---

## Overview
A multi-agent blog ideation, research, writing, and editing system orchestrated with LangChain RunnableGraph and observed via **Opik (Comet)**.

## Goals
- Turn rough ideas into high-quality blog posts.
- Support multiple blog post types with clear differentiation.
- Separate ideation, research, writing, and editing concerns.
- Maintain strong provenance and observability of outputs.

## Non-Goals
- This project is **not** philosophically centered on “context engineering.”
- No Supabase usage.

## Supported Blog Types (with Helper Text)
1. **Academic / Research**
   Deep, technical exploration grounded in prior research, best practices, and formal argumentation. Optimized for credibility and precision.
2. **Argumentative / Opinionated**
   Takes a strong stance on a controversial or debatable topic and defends it rigorously.
3. **Lessons From Experience**
   First-person narrative reflecting on real-world work (e.g., hackathons, product builds) and extracting transferable lessons.
4. **Experiential Metaphor**
   Uses a concrete everyday experience as a metaphor to illuminate a broader technical or philosophical insight.
5. **Explainer / Field Guide (NEW)**
   A practical, structured guide designed to help practitioners quickly understand and apply a concept, tool, or workflow.

## Architecture
- **Orchestration**: LangChain RunnableGraph
- **LLMs**: OpenAI-compatible APIs
- **Observability**: Opik (Comet)
- **Database Options**: NeonDB or Convex
- **Future UI**: Web app

## RunnableGraph (Conceptual)
```
User Idea
  → Agent 1 (Idea Refiner)
    → Agent 2 (Researcher w/ Web Access)
      → Agent 3 (Writer)
        → Agent 4 (Editor)
          → Final Output
```

## Data Entities
- BlogIdea
- RefinementQuestion
- Thesis
- ResearchSource
- Draft
- EditedDraft
- SocialPost

Relationships are strictly versioned; no overwrites.

---
